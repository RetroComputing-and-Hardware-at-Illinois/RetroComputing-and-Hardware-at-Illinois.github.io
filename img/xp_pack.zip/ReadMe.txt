Windows XP Desktop Theme

Installation:
If you are running Winzip or another program that automaticaly installs themes just click install. If you're running another archive program then extract files to where ever your themes are located (usually C:\Program Files\Plus!\Themes).

Included Program
I included a little thing called Icon Transparent. It gets rid of the little box of color around the text below the icons on the desktop. You are then left with just the text sitting on top of the background. This program realy gives it a Windows XP feel.

Information
*Some of the desktop wallpaper was taken off the Windows XP OS and some were found at websites and I just figured they'd look  good with Win XP.
*This theme is free to be distributed and you may put it on your website. Just leave all files intact and do not edit them  and say it's the same theme. I do give permission to use any of these files to use in your own desktop themes.