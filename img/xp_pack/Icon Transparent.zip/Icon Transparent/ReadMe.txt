
'Transparent' makes the color around icon text clear,
adding more visibility to the desktop.


Install:
1. Place this small utility in any local drive directory
you like.
2. Double-click on the 'transparent.exe' to activate
settings.
3. You should also add a shortcut to the program within
your system startup directory so that each time the
computer is started, the transparent settings
automatically take effect.

(C:\WINDOWS\Start Menu\Programs\StartUp\Transparent.lnk)


Note:
If desktop settings are changed through display
properties or desktop themes, the color around the icon
text will return to a visible state.  You will need to
activate 'Transparent' again to make the color around
the icon text clear again.


Uninstall:
To remove this utility, simply delete the 'Transparent'
directory:

(C:\Transparent)

Also remove the added shortcut file in the programs menu
startup folder:

(C:\WINDOWS\Start Menu\Programs\StartUp\Transparent.lnk)


<Enjoy!>
 